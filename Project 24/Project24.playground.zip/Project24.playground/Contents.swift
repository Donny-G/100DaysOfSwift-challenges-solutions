import UIKit

extension String {
    subscript(i: Int) -> String {
        return String(self[index(startIndex, offsetBy: i)])
    }
}



var str = "hello, playground"

str[7]

extension String {
    func deletePrefix (_ prefix: String) -> String {
        guard self.hasPrefix(prefix) else { return self }
        return String(self.dropFirst(prefix.count))
    }
}

extension String {
    func deleteSuffix (_ suffix: String) -> String {
        guard self.hasSuffix(suffix) else { return self }
        return String(self.dropLast(suffix.count))
    }
}

str.deletePrefix("he")
str.deleteSuffix("round")

extension String {
    var capitalizedFirst: String {
        guard let firstLetter = self.first else {return ""}
        return firstLetter.uppercased() + self.dropFirst()
    }
}

str.capitalizedFirst


extension String {
    func containsAny(of array: [String]) -> Bool {
        for item in array {
            if self.contains(item) {
                return true
            }
        }
        return false
    }
}

let input = "Swift is like Objective-C without the C"
let languages = ["Python", "Swift", "Ruby"]

input.containsAny(of: languages)
languages.contains(where: input.contains)


let string = "This is a test string"
let attributes: [NSAttributedString.Key: Any] = [ .foregroundColor: UIColor.white, .backgroundColor: UIColor.red, .font: UIFont.boldSystemFont(ofSize: 36)]

let attributedString = NSAttributedString(string: string, attributes: attributes)


let attributedString2 = NSMutableAttributedString(string: string)

attributedString2.addAttribute(.font, value: UIFont.systemFont(ofSize: 8), range: NSRange(location: 0, length: 4))
attributedString2.addAttribute(.font, value: UIFont.systemFont(ofSize: 16), range: NSRange(location: 5, length: 2))
attributedString2.addAttribute(.font, value: UIFont.systemFont(ofSize: 24), range: NSRange(location: 8, length: 1))
attributedString2.addAttribute(.font, value: UIFont.systemFont(ofSize: 32), range: NSRange(location: 10, length: 4))
attributedString2.addAttribute(.font, value: UIFont.systemFont(ofSize: 40), range: NSRange(location: 15, length: 6))

attributedString2

//Challenges 1
extension String {
    func withPrefix(_ prefix: String) -> String {
        if self.hasPrefix(prefix){
            return self
        } else {
            return self + prefix
        }
    }
}
var word = "car"
word.withPrefix("pet")
var word2 = "pet"
word2.withPrefix("pet")

//Challenge 2
extension String {
    func isNumeric() -> Bool {
        return Int(self) != nil
        }
}
var word3 = "abcdfe"
var word4 = "123e"
word3.isNumeric()
word4.isNumeric()

//Challenge 3
extension String {
    func lines () -> [String] {
        return self.components(separatedBy: "\n")
        }
}
var word5 = "hello\nthere\nhow\nare\nyou"
word5.lines()







