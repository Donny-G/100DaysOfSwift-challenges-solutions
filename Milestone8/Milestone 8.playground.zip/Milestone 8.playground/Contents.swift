import UIKit
extension UIView {
    func bounceOut(duration: TimeInterval) {
        UIView.animate(withDuration: duration) {
            [unowned self] in
            self.transform.scaledBy(x: 0.0001, y: 0.0001)
        }
    }
}

let view = UIView()
view.bounceOut(duration: 3)

extension Int {
    func times(_ closure: ()-> Void) {
       // guard self > 0 else {return}
        for _ in 0 ..< self{
            closure()
        }
    }
}

6.times {
    print("hi")
}

extension Array where Element: Comparable {
    mutating func remove(item: Element){
        if let location = self.firstIndex(of: item){
            self.remove(at: location)
        }
    }
}

